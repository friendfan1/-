﻿UOS 20 / Docker 18.09：net_prio 条件修复

适用现象：unable to find "net_prio" in controller set。已观察到控制器表与挂载记录都没有 net_prio，cgroup 根目录为只读 tmpfs，存在多个 v1 控制器。

1. 把此 ZIP 解压。将 fix-net-prio.sh 和 docker-up.sh 复制到原部署包的 deploy 文件夹，覆盖同名 docker-up.sh，保留原 docker.env 和数据卷。
2. 在 UOS 终端进入该 deploy 文件夹，先执行只读检查：

sudo sh fix-net-prio.sh --check

3. 只有显示“检查符合”时，执行：

sudo sh fix-net-prio.sh --apply

4. 成功后在同一 deploy 目录执行：

sudo sh docker-down.sh
sudo sh docker-up.sh

修复脚本仅在：内核和当前进程都没有 net_prio、该路径未挂载、不是符号链接、目录为空、根目录为明确的 tmpfs 且存在 v1 devices 挂载时，移除这个空目录。若根目录原来只读，则暂时设为可写并在退出时恢复原只读选项。检查不符就停止。

此操作无需重新导入镜像，不重启 Docker 或电脑；业务数据卷保留。它是本次开机的临时兼容处理；重启后若复发，需要进一步确认 UOS 创建目录的服务并作持久配置修正。

如果检查拒绝操作，或出现恢复只读状态失败，不要继续启动；把输出发来继续处理。此修复的保护分支已在临时文件系统和模拟挂载下通过17项测试，真实 UOS 执行结果仍待验证。
