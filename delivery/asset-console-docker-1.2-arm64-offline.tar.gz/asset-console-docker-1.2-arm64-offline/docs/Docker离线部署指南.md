# 统信 UOS ARM64：Docker 离线部署指南

当前交付 V1.2。已部署用户优先参阅 [V1.2 离线升级步骤](V1.2离线升级步骤.md)，沿用现有可用 Docker、配置和数据卷。导入功能见 [Excel 批量导入使用说明](Excel批量导入使用说明.md)。

## 1. 部署形态与交付物

本方案面向 **ARM64 统信 UOS、Docker 18.09.1（build 4c52b90）**，宿主机无需安装 Python，也不需要访问互联网。

一份 ARM64 Linux 镜像启动两个容器：

| 名称 | 用途 |
| --- | --- |
| `asset-console-web` | 初始化数据库、提供页面、维护、导出与日志 |
| `asset-console-monitor` | 定时及按请求 Ping 工作网终端 |
| `asset-console-data` | 两个容器共享的命名数据卷，保留 SQLite、密钥及备份 |

镜像内包含 Python、应用依赖、本地静态资源和系统 Ping。应用进程使用非 root 的 UID/GID `10001:10001`。查看和导出免登录，资产维护需要管理员登录；初始不带账号和真实资产数据。

部署不使用 Compose、buildx，也不要求宿主机在线构建。目标机只需已有可用的 Docker、普通 Linux shell 及离线镜像文件。

交付时应同时取得：

- 使用 `docker save` 生成的 **ARM64 镜像归档**，及配套 SHA256 校验文件。
- `deploy/docker-up.sh`、`deploy/docker-down.sh`、`deploy/docker.env.example` 和本指南。

**普通源码 `.tar.gz` 不是 Docker 镜像，不能用 `docker load` 导入。** 本次交付文件为 `asset-console-docker-1.2-arm64-offline.tar.gz`，先解压外层交付包，再导入里面的 `asset-console-1.2-arm64.image.tar.gz`；镜像标签为 `asset-console:1.2-arm64`。

```sh
sha256sum -c asset-console-docker-1.2-arm64-offline.tar.gz.sha256
tar -xzf asset-console-docker-1.2-arm64-offline.tar.gz
cd asset-console-docker-1.2-arm64-offline
```

## 2. 确认宿主机与导入镜像

在 UOS 服务器执行：

```sh
uname -m
docker version
docker info
```

`uname -m` 应为 `aarch64` 或 `arm64`。确保 Docker 服务正常，当前运维账号有执行 Docker 的权限。

把镜像及校验文件通过单位认可的方式转移到内网，然后执行：

```sh
sha256sum -c asset-console-1.2-arm64.image.tar.gz.sha256
docker load -i asset-console-1.2-arm64.image.tar.gz
docker image inspect --format '{{.Os}}/{{.Architecture}}' asset-console:1.2-arm64
```

最后一条应输出 `linux/arm64`。不要执行 `docker pull`，也不要把 AMD64 镜像放到 ARM64 机器上运行。若本地未导入正确镜像，启动脚本会退出，不尝试联网拉取。

## 3. 配置内网访问地址

在交付目录中复制示例配置：

```sh
cp deploy/docker.env.example deploy/docker.env
chmod 600 deploy/docker.env
```

用文本编辑器修改 `deploy/docker.env`：

```text
APP_DATA_DIR=/data
APP_BIND=0.0.0.0
APP_PORT=8000
APP_ALLOWED_HOSTS=127.0.0.1,localhost,10.10.1.10
APP_PING_INTERVAL_SECONDS=300
APP_PING_TIMEOUT_SECONDS=2
APP_PING_WORKERS=8
APP_PING_STALE_SECONDS=600
```

将 `10.10.1.10` 换成实际 UOS 服务器的内网 IP；如通过内网域名访问，也加入该域名。保留 `127.0.0.1`，供容器本地就绪检查使用。无需填写客户端各电脑的 IP。

配置文件使用 Docker 的 `KEY=value` 格式，不写 `export`、引号或 shell 命令，不在等号两侧加空格。它作为 `--env-file` 读取，不作为 shell 脚本执行。

`APP_SECRET_KEY` 可不配置，应用会把私有密钥持久化到数据卷中的 `/data/secret_key`。不要在配置示例、聊天或日志中填写或显示真实密码和密钥。

## 4. 启动两个容器

```sh
sh deploy/docker-up.sh
```

配置文件放在其他位置时：

```sh
sh deploy/docker-up.sh /path/to/docker.env
```

脚本按顺序进行：

1. 检查 Docker、本地镜像存在性及其 CPU 架构；镜像缺失或架构不匹配即停止。
2. 检查是否已有同名容器，拒绝覆盖；已有数据卷须带本系统管理标记，否则拒绝擅自使用。
3. 创建或复用本系统数据卷，启动 Web 容器。
4. Web 独自迁移数据库、收集本地静态资源并启动服务；脚本确认页面服务及数据库就绪。
5. 再启动检测容器。检测入口只等待数据库迁移完成，不并发执行迁移。

启动失败时，脚本只清理本次创建的容器，保留数据卷。正常启动后可查看：

```sh
docker ps
docker logs --tail 100 asset-console-web
docker logs --tail 100 asset-console-monitor
```

镜像自带的健康检查访问 Web 的 `/health/`，用于检查页面服务和数据库。检测容器不是 Web 服务，启动脚本为它设置 `--no-healthcheck`；其运行情况应结合容器日志和页面最后检测时间判断，不能套用 Web 健康检查。在 host 网络下，两容器共用宿主网络命名空间，更不能把检测容器访问到 Web 端口误当作检测进程本身健康。

首次创建维护管理员：

```sh
docker exec -it asset-console-web python manage.py init_admin
```

按提示输入账号和密码。没有默认管理员密码，也不需要在宿主机安装 Python。然后在客户端浏览器地址栏输入服务器内网 IP 和端口，例如 `http://10.10.1.10:8000`。

## 5. 网络与 Ping 权限

两个容器使用 Linux `--network host`：服务直接监听宿主机的配置端口，通常可以取得实际客户端来源 IP，并使用宿主机到工作网终端的路由。无需 `-p` 端口映射，服务器上该端口须未被其他程序占用。

仅向单位所需内网范围开放端口。此方案不设置外网连接，不需要在线 CDN、在线依赖或外部 API。网络模式本身不代替单位防火墙策略。

检测容器只保留 `NET_RAW` 能力；Web 容器删除所有额外能力。镜像中的 Ping 还须具备正确的文件能力／系统配置，以便非 root 账号执行 ICMP。实际可用性受 UOS 内核、Docker 运行时、存储驱动和安全策略影响，需要在目标机验证：

```sh
docker exec asset-console-monitor id
docker exec asset-console-monitor ping -c 1 -W 2 127.0.0.1
```

再对一台已知允许 Ping 的工作网终端执行检查：

```sh
docker exec asset-console-monitor ping -c 1 -W 2 工作网终端的实际IP
```

前一个命令验证基本执行权限，后一个验证真实路由、防火墙及终端 ICMP 策略。互联网终端及打印机不参与在线探测。未响应不等于确认关机。

若出现 `Operation not permitted` 等错误，检查日志及 UOS/Docker 的 ICMP 能力配置。不要通过 `--privileged`、关闭 seccomp 或以 root 运行整个应用来掩盖问题。检测失败应显示“检测异常”，不能统一当作设备离线。

## 6. 停机、重启与数据保留

停止并移除本系统两个容器：

```sh
sh deploy/docker-down.sh
```

脚本先验证两个容器的系统标记，再停止并删除对应容器；**不会删除数据卷**。之后再次运行 `docker-up.sh`，继续使用原资产、账号、日志及密钥。

容器配置为 `unless-stopped` 重启策略。宿主机重启后 Docker 服务也应自启动；手工停止的容器不会被该策略自动恢复，需根据实际运维流程启动或重建。

不要执行 `docker volume rm asset-console-data` 或清理在用数据卷。删除容器和删除数据卷是不同操作。

如需自定义名称或使用另一份已导入镜像，在执行脚本的 shell 中设置：

```sh
APP_IMAGE=asset-console:1.2-arm64 APP_DATA_VOLUME=asset-console-data sh deploy/docker-up.sh
```

可用控制变量还有 `APP_WEB_CONTAINER`、`APP_MONITOR_CONTAINER`、`APP_DOCKER_PLATFORM`。自定义容器／卷名称后，停机及维护命令必须使用相同名称；这些是启动脚本参数，不要误写到容器应用的 env 文件中。平台仅接受 `arm64` 或 `amd64`，必须与实际宿主机一致，不能借此绕过架构检查。

## 7. 一致性备份

服务运行期间可用容器内的备份工具生成资产、账号和审计日志一致的 SQLite 快照：

```sh
docker exec asset-console-web python scripts/backup.py --output /data/backups/assets-manual.sqlite3
```

相同文件名已存在时会拒绝覆盖，建议每次使用带日期的不同文件名。复制备份到宿主机受控目录：

```sh
umask 077
mkdir -p /safe-backup
docker cp asset-console-web:/data/backups/assets-manual.sqlite3 /safe-backup/assets-manual.sqlite3
chmod 600 /safe-backup/assets-manual.sqlite3
```

数据库备份不包含密钥。首次部署后，以及迁移服务器前，应另行受控保留密钥文件；以下命令只复制文件，不显示密钥内容：

```sh
docker cp asset-console-web:/data/secret_key /safe-backup/secret_key
chmod 600 /safe-backup/secret_key
```

备份应存放在授权运维人员可访问的位置，并定期转移到其他受控介质，不能只放在同一服务器硬盘。

## 8. 停机恢复

先停止并移除两个业务容器，保留数据卷：

```sh
sh deploy/docker-down.sh
```

备份通过只读目录绑定提供给一次性工具容器。因为工具使用 UID `10001`，宿主机目录及文件必须允许该 UID 读取；可由运维人员准备独立恢复目录：

```sh
install -d -m 700 -o 10001 -g 10001 /srv/asset-console-restore
install -m 600 -o 10001 -g 10001 /safe-backup/assets-manual.sqlite3 /srv/asset-console-restore/assets.sqlite3
```

先核对本地镜像存在；只有成功读取镜像 ID 才运行工具容器，避免隐式拉取：

```sh
if TASK_IMAGE_ID=$(docker image inspect --format '{{.Id}}' asset-console:1.2-arm64); then
    docker run --rm --network none --user 10001:10001 \
        --cap-drop ALL --security-opt no-new-privileges \
        --env-file deploy/docker.env -e APP_DATA_DIR=/data \
        -v asset-console-data:/data \
        -v /srv/asset-console-restore:/backup:ro \
        "$TASK_IMAGE_ID" python scripts/restore.py /backup/assets.sqlite3 \
        --confirm --services-stopped
else
    printf '%s\n' '本地镜像缺失，请先离线导入；未执行恢复。'
fi
```

工具先校验数据库来源和完整性，再自动保留恢复前数据库，成功后才替换目标库。相同数据卷中的密钥保持不变。之后运行 `docker-up.sh`，由 Web 执行必要迁移再恢复服务；核对资产数量、日志和管理员登录。

迁移到全新服务器时，先按前文创建本系统数据卷并停机，再恢复备份。应通过受控方式把原 `secret_key` 恢复到同一数据卷并保持 `10001:10001` 所有权和 `600` 权限；若使用新生成的密钥，旧浏览器会话会失效，需要重新登录。

## 9. 离线升级

1. 先备份数据库及密钥，停止两个业务容器，保留数据卷。
2. 校验并 `docker load` 导入新 ARM64 镜像。
3. 更新启动脚本、配置和 `APP_IMAGE` 指向的新标签。
4. 运行启动脚本；Web 迁移完成后检测容器启动。
5. 核对资产、日志、导出和在线检测。

旧镜像在验证完成前保留。回退镜像不代表自动回退数据库结构；必要时使用对应版本的升级前备份，并保留回退前新产生的数据。

## 10. 现场验收

- 在实际 ARM64 UOS、Docker 18.09.1 上离线导入、启动、停止和重建。
- 不依赖宿主机 Python；容器使用非 root UID；未使用 privileged 或关闭 seccomp。
- 资产、账号、日志及密钥在重建容器后仍保留。
- 未导入镜像、架构错误、同名无关容器／数据卷时，脚本停止且不覆盖、不拉取。
- Chrome 83 可查看、导出和登录维护；页面资源无外网请求。
- 日志记录实际来源 IP；代理部署时另行配置可信代理。
- 检测容器具备 ICMP 权限，并与工作网真实连通性一致。
- 完成一次数据库备份和停机恢复。

脚本语法和模拟命令测试不能代替真实 Docker、ARM64 UOS、旧版内核和 Chrome 83 的现场验证。AMD64 容器实测及通过显式 QEMU 执行 ARM64 也不能替代目标 UOS 上 Docker 18.09.1 的导入和运行验收；云环境中的 cgroup 限制可能使旧版 daemon 无法启动，不能因此声称已实测该旧版 Docker。若交付报告未记录某项实测结果，该项应按现场待验收处理。
