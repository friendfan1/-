#!/bin/sh
# Stop and remove only explicitly labelled application containers; retain data.
set -eu
TASK_WEB=${APP_WEB_CONTAINER:-asset-console-web}
TASK_MONITOR=${APP_MONITOR_CONTAINER:-asset-console-monitor}
TASK_VOLUME=${APP_DATA_VOLUME:-asset-console-data}

fail() { printf '%s\n' "$*" >&2; exit 1; }
command -v docker >/dev/null 2>&1 || fail '找不到 Docker 命令。'
docker info >/dev/null 2>&1 || fail '无法连接 Docker 服务。'
[ "$TASK_WEB" != "$TASK_MONITOR" ] || fail '两个容器名称不能相同。'

# Validate both targets before touching either, so an unrelated same-name
# container never gets removed by an environment-variable typo.
for TASK_PAIR in "$TASK_MONITOR:monitor" "$TASK_WEB:web"; do
    TASK_CONTAINER=${TASK_PAIR%:*}
    TASK_ROLE=${TASK_PAIR##*:}
    case "$TASK_CONTAINER" in ''|*[!a-zA-Z0-9_.-]*|-*|.*) fail '容器名称不合法。' ;; esac
    if docker container inspect "$TASK_CONTAINER" >/dev/null 2>&1; then
        TASK_OWNER=$(docker inspect --format '{{index .Config.Labels "org.asset-console.managed"}}' "$TASK_CONTAINER")
        TASK_ACTUAL_ROLE=$(docker inspect --format '{{index .Config.Labels "org.asset-console.role"}}' "$TASK_CONTAINER")
        [ "$TASK_OWNER" = true ] && [ "$TASK_ACTUAL_ROLE" = "$TASK_ROLE" ] || fail "容器 $TASK_CONTAINER 不是对应的资产系统容器，拒绝删除。"
    fi
done

for TASK_CONTAINER in "$TASK_MONITOR" "$TASK_WEB"; do
    if docker container inspect "$TASK_CONTAINER" >/dev/null 2>&1; then
        docker stop -t 30 "$TASK_CONTAINER" >/dev/null
        docker rm "$TASK_CONTAINER" >/dev/null
        printf '已停止并移除容器：%s\n' "$TASK_CONTAINER"
    fi
done
printf '数据卷保留：%s；未执行任何 docker volume rm 操作。\n' "$TASK_VOLUME"
