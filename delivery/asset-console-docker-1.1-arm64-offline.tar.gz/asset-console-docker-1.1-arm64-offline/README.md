# 序衡 · 信息化资产管理系统

面向单位内网的小规模资产台账：工作网终端、互联网终端、打印机集中登记，数据总览、工作网 Ping 检测、Excel 导出和来源 IP 审计。设计规模为设备不超过 50 台、同时使用不超过 5 人。

- 查看资产、大屏和导出不需要登录；新增、修改、删除、手动检测和操作日志需要维护员登录。
- 页面资源全部本地提供，没有在线 CDN、字体或外部接口。
- 服务端采用 Python / Django / SQLite / Waitress，支持 ARM64 Linux 部署；用户使用 Chrome 83 或更高版本浏览器访问即可，Win7 客户端不用安装 Git。
- 工作网终端由服务器执行 Ping；互联网终端及打印机不探测。未响应不等于确认关机。
- 每条资产保留资料最后更新时间；导出时间、检测时间单独记录。

## 正式部署：Docker 18.09.1 离线镜像

正式部署使用 **ARM64 Docker 镜像**，宿主机只需要可用的 Docker 18.09.1（build 4c52b90）及 Linux shell，**不用安装 Python、pip 或数据库，不需要互联网**。Python、全部依赖、Ping 和页面资源均包含在镜像中。

取得 `asset-console-docker-1.1-arm64-offline.tar.gz` 后先核对配套 SHA256，解压并进入交付目录。注意外层是交付包，真正供 Docker 导入的是里面的 `.image.tar.gz`：

```sh
docker load -i asset-console-1.1-arm64.image.tar.gz
cp deploy/docker.env.example deploy/docker.env
chmod 600 deploy/docker.env
# 使用文本编辑器将 APP_ALLOWED_HOSTS 中的示例地址改为实际服务器内网 IP。
sh deploy/docker-up.sh
docker exec -it asset-console-web python manage.py init_admin
```

详细的导入、备份恢复、升级及 Ping 检查见 [Docker 离线部署指南](docs/Docker离线部署指南.md)。运行 Web 和检测两个非 root 容器，共享命名数据卷；停机脚本保留资产、账号、日志和密钥。启动前检查本地镜像，镜像缺失时停止，不会隐式联网拉取。

此前 8 MB 左右的源码依赖离线包不包含 Python 运行时，不能代替 Docker 镜像。下文非容器启动步骤保留给开发环境和已有 Python 的测试环境，不是单位内网正式部署的前置条件。

## 非容器启动（仅开发环境，有网络）

需要 Python 3.11 或更新版本，建议 Python 3.12；定时在线检测还需要操作系统自带的 `ping` 命令。

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python manage.py migrate --noinput
.venv/bin/python manage.py collectstatic --noinput
.venv/bin/python manage.py init_admin
.venv/bin/python serve.py
```

另开终端，在同一目录启动检测进程：

```sh
.venv/bin/python manage.py monitor_assets
```

浏览器访问服务器配置的地址和端口。默认只监听本机；允许其他内网电脑访问时，须设置 `APP_BIND=0.0.0.0`，并将实际服务器 IP 或域名加入 `APP_ALLOWED_HOSTS`，详见部署指南。

系统初始为空，不内置默认密码。`init_admin` 交互创建维护员。只有需要演示时才显式运行以下命令，生产部署不要执行：

```sh
.venv/bin/python manage.py seed_demo
```

## 非容器源码依赖包（仅开发／测试）

正式内网部署使用上方 Docker 交付包，不需要宿主机 Python。以下保留给已有 Python 的开发／测试环境，完整操作见 [非容器部署参考](docs/部署指南.md)。此源码依赖包包含应用与纯 Python 依赖，不包含服务器 Python 运行时、系统 `ping`、真实数据库或密钥，不能代替 Docker 镜像。

在有网机器准备离线包：

```sh
.venv/bin/python scripts/build_offline.py
```

将生成的归档及 `.sha256` 校验文件转移至内网，按指南解压、校验并安装：

```sh
sh scripts/install_offline.sh
```

## 日常使用

1. 未登录时可以看大屏、查询资产、查看详情、导出 Excel。
2. 维护员登录后登记、修改或删除资产；删除保留审计记录。
3. 工作网在线结果由检测进程更新，页面显示最后检测时间，过期结果不当作当前在线数。
4. 资产技术参数未知时可以暂留空；同类网络 IP、序列号或 MAC 重复会给出提醒。
5. 日志展示来源 IP 及每个字段修改前后的值。数据库管理员仍需按单位制度管理数据文件和备份。

## 备份与恢复

```sh
.venv/bin/python scripts/backup.py
```

数据库备份一致地包含资产、账号和审计日志；密钥文件 `data/secret_key` 须另行安全保留，切勿放进代码仓库或离线公开交付包。

恢复前必须停止 Web 和检测进程：

```sh
.venv/bin/python scripts/restore.py /path/to/backup.sqlite3 --confirm --services-stopped
.venv/bin/python manage.py migrate --noinput
```

恢复工具先校验备份，且自动保存恢复前的数据库，不会静默覆盖已有备份。完成后重启两个进程。

## 验证

```sh
.venv/bin/python manage.py check
.venv/bin/python manage.py test
.venv/bin/python -m unittest discover -s scripts -p 'test_*.py'
```

已在云端 Linux x86_64 的真实 Chrome 83.0.4103.0 中完成核心流程验证。目标 ARM64 UOS 和 Win7 客户端仍需现场验收，详见 [验证报告](docs/验证报告.md)。开发需求依据见 [需求说明书](docs/信息化资产管理系统需求说明书-v1.0.md)。
